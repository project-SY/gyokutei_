<a href="#" class="pagetop sp"><img src="./images/btn-footer-pagetop-sp.png" alt="ページトップへ戻る"></a>
    <footer id="footer">
      <div class="footer-bg-high">
        <p>
        箱根湯本温泉　玉庭(ぎょくてい)<br />
        250-0311　神奈川県足柄下郡箱根町湯本501
      </p>
      </div>
      <p>
        TEL: 0560-85-8501　FAX: 0460-85-8505
      </p>
    </footer>
  </div>
</div>
</body>
</html>
