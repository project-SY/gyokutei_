<div id="nav">
    <a class="logo" href="index.php"><img src="./images/logo.png" alt="玉庭"></a>
    <a class="open-btn btn"><img class="close" src="./images/btn-menu-on-sp.png" alt=""></a>
    <div id="sidr-right" class="sidr right">
      <div class="inner">
        <div class="close-btn-area clearfix">
          <a class="close-btn btn" href="#"><img src="./images/btn-menu-off-sp.png" alt=""></a>
        </div>
        <ul>
          <li><a href="index.php"><img src="./images/txt-sidebar-top.png" alt="トップ"></a></li>
          <li><a href="bath.php"><img src="./images/txt-sidebar-bath.png" alt="お風呂"></a></li>
          <li><a href="room.php"><img src="./images/txt-sidebar-room.png" alt="お部屋"></a></li>
          <li><a href=""><img src="./images/txt-sidebar-food.png" alt="お料理"></a></li>
          <li><a href="reservation.php"><img src="./images/txt-sidebar-reservation.png" alt="予約"></a></li>
          <li><a href="access.php"><img src="./images/txt-sidebar-access.png" alt="交通"></a></li>
          <li><a href=""><img src="./images/txt-sidebar-blog.png" alt="ブログ"></a></li>
        </ul>
      </div>
    </div>
  </div>