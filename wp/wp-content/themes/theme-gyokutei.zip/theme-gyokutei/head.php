<!DOCTYPE html>
<html lang="ja">
<?php include('meta.php'); ?>
<body>

<!-- wrapper start -->
<div id="wrapper" class="clearfix no-active">