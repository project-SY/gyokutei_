<head>
<meta charset="UTF-8" />
<title>玉庭</title>
<meta name="keywords" content="###">
<meta name="description" content="###" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
<meta property="og:type" content="###" />
<meta property="og:url" content="###" />
<meta property="og:title" content="###" />
<meta property="og:description" content="###" />
<meta property="og:image" content="###" />
<link rel="shortcut icon" href="favicon.ico" />
<link rel="stylesheet" href="./css/reset.css">
<link rel="stylesheet" href="./css/style.css">
<script src="./js/jquery-1.11.3.min.js"></script>
<script src="./js/jquery.sidr.min.js"></script>
<script src="./js/jquery.bxslider.min.js"></script>
<script src="./js/common.js"></script>
</head>